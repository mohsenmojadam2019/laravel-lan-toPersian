<?php

namespace TS\Utilities\Classes;

class Lang
{
    public static array $data = [];
    public static array $loaded = [];
    public static string $locale;

    public static function path()
    {
        return dirname(__FILE__, 3) . '/shared/lang/' . self::$locale . '.json';
    }

    public static function load()
    {
        if (isset(self::$loaded[self::$locale]) && self::$loaded[self::$locale]) return;
        self::$loaded[self::$locale] = true;
        if (file_exists(self::path())) {
            $content = file_get_contents(self::path());
            self::$data[self::$locale] = json_decode($content, true);
        } else {
            self::$data[self::$locale] = [];
        }
    }

    public static function get($key, $locale = '')
    {
        self::$locale = $locale ?: ts_env('locale', 'fa');
        self::load();
        $value = self::$data[self::$locale];
        $value = array_dot($value);
        return $value[$key] ?? $key;
    }
}