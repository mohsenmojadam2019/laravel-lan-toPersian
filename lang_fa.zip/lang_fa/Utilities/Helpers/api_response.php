<?php

if(!function_exists('api_response')) {
    /**
     * @param $status
     * @param $message
     * @param $data
     * @return array
     */
    function api_response($status, $message, $data): array
    {
        if($status) {
            return ['status' => $status, 'message' => ts_lang('ok'), 'data' => $data];
        }
        return ['status' => $status, 'message' => $message, 'data' => $data];
    }
}
