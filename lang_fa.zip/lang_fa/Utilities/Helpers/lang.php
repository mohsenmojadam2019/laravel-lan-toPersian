<?php
if (! function_exists('ts_lang')) {
    /**
     * Translate the given message.
     *
     * @param  string  $key
     * @param  string  $locale
     * @return \Illuminate\Contracts\Translation\Translator|string|array|null
     */
    function ts_lang($key, $locale = '')
    {
        return \TS\Utilities\Classes\Lang::get($key, $locale);
    }
}
